'use strict';

const {
  app,
  BrowserWindow,
  WebContentsView,
  ipcMain,
  globalShortcut,
  shell,
  Menu,
} = require('electron');
const path = require('path');
const Database = require('better-sqlite3');

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTS & CONFIG
// ─────────────────────────────────────────────────────────────────────────────

const URLS = {
  ddb: 'https://www.dndbeyond.com',       // Replace with your party's character sheet URL
  roll20: 'https://app.roll20.net',       // Replace with your campaign URL
  discord: 'https://discord.com/app',     // Web Discord, filtered to your server
};

// Layout proportions (as fractions of window width)
const LAYOUT = {
  ddb:     { widthFrac: 0.35 },
  roll20:  { widthFrac: 0.42 },
  discord: { widthFrac: 0.23 },
  // Chrome/toolbar reserve at the top (for our custom overlay bar)
  toolbarHeight: 40,
};

const IS_DEV = process.argv.includes('--dev');

// ─────────────────────────────────────────────────────────────────────────────
// DATABASE — SESSION LOGGING
// ─────────────────────────────────────────────────────────────────────────────

let db;

function initDatabase() {
  const dbPath = path.join(app.getPath('userData'), 'sessions.db');
  db = new Database(dbPath);

  db.exec(`
    CREATE TABLE IF NOT EXISTS rolls (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id  TEXT    NOT NULL,
      timestamp   TEXT    NOT NULL,
      source      TEXT    NOT NULL,  -- 'ddb' | 'manual'
      expression  TEXT    NOT NULL,  -- e.g. "1d20+5"
      result      INTEGER,
      label       TEXT,              -- e.g. "Perception Check"
      is_crit     INTEGER DEFAULT 0,
      is_fumble   INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id          TEXT    PRIMARY KEY,
      started_at  TEXT    NOT NULL,
      ended_at    TEXT,
      notes       TEXT
    );

    CREATE TABLE IF NOT EXISTS events (
      id          INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id  TEXT    NOT NULL,
      timestamp   TEXT    NOT NULL,
      type        TEXT    NOT NULL,  -- 'hotkey' | 'roll' | 'system' | 'custom'
      payload     TEXT               -- JSON blob
    );
  `);

  console.log('[DB] Database ready at', dbPath);
  return db;
}

// Start a new session and return its ID
function startSession() {
  const id = `session_${Date.now()}`;
  const now = new Date().toISOString();
  db.prepare(`INSERT INTO sessions (id, started_at) VALUES (?, ?)`).run(id, now);
  console.log('[DB] Session started:', id);
  return id;
}

function logRoll({ sessionId, source, expression, result, label, isCrit, isFumble }) {
  db.prepare(`
    INSERT INTO rolls (session_id, timestamp, source, expression, result, label, is_crit, is_fumble)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    sessionId,
    new Date().toISOString(),
    source,
    expression,
    result ?? null,
    label ?? null,
    isCrit ? 1 : 0,
    isFumble ? 1 : 0,
  );
}

function logEvent({ sessionId, type, payload }) {
  db.prepare(`
    INSERT INTO events (session_id, timestamp, type, payload)
    VALUES (?, ?, ?, ?)
  `).run(sessionId, new Date().toISOString(), type, JSON.stringify(payload ?? {}));
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN WINDOW + WEBCONTENTSVIEWS
// ─────────────────────────────────────────────────────────────────────────────

let mainWindow;
let views = {};   // { ddb, roll20, discord }
let sessionId;

function createWindow() {
  // Full borderless window — feels like a native app
  mainWindow = new BrowserWindow({
    width: 2560,
    height: 1440,
    minWidth: 1280,
    minHeight: 720,
    backgroundColor: '#0d1117',
    titleBarStyle: 'hidden',
    titleBarOverlay: {
      color: '#0d1117',
      symbolColor: '#a78bfa',
      height: LAYOUT.toolbarHeight,
    },
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload-main.js'),
    },
    icon: path.join(__dirname, '..', 'assets', 'icon.png'),
    show: false,
  });

  // Load our thin overlay UI (toolbar, status indicators)
  mainWindow.loadFile(path.join(__dirname, '..', 'renderer', 'index.html'));

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    if (IS_DEV) mainWindow.webContents.openDevTools({ mode: 'detach' });
    tileViews();
    registerGlobalHotkeys();
  });

  mainWindow.on('resize', () => tileViews());
  mainWindow.on('closed', () => { mainWindow = null; });
}

// ── View Factory ─────────────────────────────────────────────────────────────

function createView(key, url, preloadFile) {
  const view = new WebContentsView({
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: preloadFile ? path.join(__dirname, preloadFile) : undefined,
      partition: `persist:${key}`,  // Each view keeps its own cookies/session
    },
  });

  mainWindow.contentView.addChildView(view);

  view.webContents.loadURL(url);

  // Open external links in the OS browser, not a new Electron window
  view.webContents.setWindowOpenHandler(({ url: targetUrl }) => {
    shell.openExternal(targetUrl);
    return { action: 'deny' };
  });

  if (IS_DEV) {
    view.webContents.on('did-finish-load', () => {
      console.log(`[VIEW:${key}] Loaded: ${view.webContents.getURL()}`);
    });
  }

  return view;
}

// ── Tiling Logic ─────────────────────────────────────────────────────────────

function tileViews() {
  if (!mainWindow) return;

  const [winWidth, winHeight] = mainWindow.getContentSize();
  const top = LAYOUT.toolbarHeight;
  const availH = winHeight - top;

  const ddbW     = Math.floor(winWidth * LAYOUT.ddb.widthFrac);
  const discordW = Math.floor(winWidth * LAYOUT.discord.widthFrac);
  const roll20W  = winWidth - ddbW - discordW;

  const positions = {
    ddb:     { x: 0,               y: top, width: ddbW,     height: availH },
    roll20:  { x: ddbW,            y: top, width: roll20W,  height: availH },
    discord: { x: ddbW + roll20W,  y: top, width: discordW, height: availH },
  };

  for (const [key, bounds] of Object.entries(positions)) {
    if (views[key]) {
      views[key].setBounds(bounds);
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// IPC — NERVOUS SYSTEM
// ─────────────────────────────────────────────────────────────────────────────

function setupIPC() {

  // ── DDB Roll Detected (from preload-ddb.js) ───────────────────────────────
  ipcMain.on('ddb:roll-detected', (event, rollData) => {
    console.log('[IPC] Roll detected from DDB:', rollData);

    // 1. Log to DB
    logRoll({
      sessionId,
      source: 'ddb',
      expression: rollData.expression,
      result: rollData.result,
      label: rollData.label,
      isCrit: rollData.isCrit,
      isFumble: rollData.isFumble,
    });
    logEvent({ sessionId, type: 'roll', payload: rollData });

    // 2. Bridge to Roll20
    if (views.roll20) {
      bridgeRollToRoll20(rollData);
    }

    // 3. Notify toolbar overlay
    mainWindow.webContents.send('overlay:roll-flash', rollData);
  });

  // ── Manual roll from toolbar ──────────────────────────────────────────────
  ipcMain.on('manual:roll', (event, rollData) => {
    logRoll({ sessionId, source: 'manual', ...rollData });
    if (views.roll20) bridgeRollToRoll20(rollData);
    mainWindow.webContents.send('overlay:roll-flash', rollData);
  });

  // ── Toolbar requests recent rolls ─────────────────────────────────────────
  ipcMain.handle('db:get-recent-rolls', () => {
    return db.prepare(`
      SELECT * FROM rolls
      WHERE session_id = ?
      ORDER BY id DESC
      LIMIT 50
    `).all(sessionId);
  });

  // ── Toolbar requests session summary ──────────────────────────────────────
  ipcMain.handle('db:get-session-stats', () => {
    const stats = db.prepare(`
      SELECT
        COUNT(*)                           AS total_rolls,
        SUM(is_crit)                       AS total_crits,
        SUM(is_fumble)                     AS total_fumbles,
        ROUND(AVG(result), 1)              AS avg_result,
        MAX(result)                        AS highest_roll,
        MIN(result)                        AS lowest_roll
      FROM rolls
      WHERE session_id = ?
    `).get(sessionId);
    return stats;
  });

  // ── View reload (toolbar button) ──────────────────────────────────────────
  ipcMain.on('view:reload', (event, key) => {
    if (views[key]) {
      views[key].webContents.reload();
      logEvent({ sessionId, type: 'system', payload: { action: 'reload', view: key } });
    }
  });

  // ── Navigate a view to a new URL ──────────────────────────────────────────
  ipcMain.on('view:navigate', (event, { key, url }) => {
    if (views[key]) {
      views[key].webContents.loadURL(url);
    }
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// ROLL20 BRIDGE
// ─────────────────────────────────────────────────────────────────────────────

async function bridgeRollToRoll20(rollData) {
  const { expression, label, result, isCrit, isFumble } = rollData;

  // Craft a Roll20 /roll command
  // Roll20 accepts: /roll 1d20+5 [Perception Check]
  const labelStr = label ? ` [${label}]` : '';
  const rollCmd  = `/roll ${expression}${labelStr}\n`;

  // Inject via executeJavaScript — finds the Roll20 chat input and submits
  const script = `
    (function() {
      const input = document.querySelector('#textchat-input textarea');
      if (!input) return false;

      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
        window.HTMLTextAreaElement.prototype, 'value'
      ).set;
      nativeInputValueSetter.call(input, ${JSON.stringify(rollCmd)});
      input.dispatchEvent(new Event('input', { bubbles: true }));

      const form = input.closest('form');
      if (form) {
        form.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }));
        return true;
      }

      // Fallback: simulate Enter key
      input.dispatchEvent(new KeyboardEvent('keydown', {
        key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true
      }));
      return true;
    })();
  `;

  try {
    const success = await views.roll20.webContents.executeJavaScript(script);
    if (!success) {
      console.warn('[ROLL20] Chat input not found — Roll20 page may not be fully loaded.');
    } else {
      console.log(`[ROLL20] Bridged roll: ${expression} → result ${result}`);
    }
  } catch (err) {
    console.error('[ROLL20] Bridge failed:', err.message);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// GLOBAL HOTKEYS
// ─────────────────────────────────────────────────────────────────────────────

function registerGlobalHotkeys() {

  const hotkeys = [

    // ── Discord mute toggle ───────────────────────────────────────────────
    {
      accelerator: 'CommandOrControl+M',
      label: 'Mute Discord',
      action: () => {
        if (!views.discord) return;
        // Discord Web: Click the mute button in the voice controls
        views.discord.webContents.executeJavaScript(`
          (function() {
            const btn = document.querySelector('[aria-label="Mute"]') ||
                        document.querySelector('[aria-label="Unmute"]');
            if (btn) btn.click();
          })();
        `);
        logEvent({ sessionId, type: 'hotkey', payload: { key: 'Ctrl+M', action: 'discord-mute-toggle' } });
      },
    },

    // ── Roll20: Center map ────────────────────────────────────────────────
    {
      accelerator: 'CommandOrControl+R',
      label: 'Center Roll20 Map',
      action: () => {
        if (!views.roll20) return;
        // Roll20 'Space' centers the map when the canvas is focused
        views.roll20.webContents.executeJavaScript(`
          (function() {
            const canvas = document.querySelector('#playerzone');
            if (canvas) {
              canvas.focus();
              canvas.dispatchEvent(new KeyboardEvent('keydown', {
                key: ' ', code: 'Space', keyCode: 32, which: 32, bubbles: true
              }));
            }
          })();
        `);
        logEvent({ sessionId, type: 'hotkey', payload: { key: 'Ctrl+R', action: 'roll20-center-map' } });
      },
    },

    // ── Focus DDB panel ───────────────────────────────────────────────────
    {
      accelerator: 'CommandOrControl+1',
      label: 'Focus D&D Beyond',
      action: () => {
        if (views.ddb) views.ddb.webContents.focus();
        logEvent({ sessionId, type: 'hotkey', payload: { key: 'Ctrl+1', action: 'focus-ddb' } });
      },
    },

    // ── Focus Roll20 panel ────────────────────────────────────────────────
    {
      accelerator: 'CommandOrControl+2',
      label: 'Focus Roll20',
      action: () => {
        if (views.roll20) views.roll20.webContents.focus();
        logEvent({ sessionId, type: 'hotkey', payload: { key: 'Ctrl+2', action: 'focus-roll20' } });
      },
    },

    // ── Focus Discord panel ───────────────────────────────────────────────
    {
      accelerator: 'CommandOrControl+3',
      label: 'Focus Discord',
      action: () => {
        if (views.discord) views.discord.webContents.focus();
        logEvent({ sessionId, type: 'hotkey', payload: { key: 'Ctrl+3', action: 'focus-discord' } });
      },
    },

    // ── Reload all views ──────────────────────────────────────────────────
    {
      accelerator: 'CommandOrControl+Shift+R',
      label: 'Reload All Panels',
      action: () => {
        for (const view of Object.values(views)) {
          view.webContents.reload();
        }
        logEvent({ sessionId, type: 'hotkey', payload: { key: 'Ctrl+Shift+R', action: 'reload-all' } });
      },
    },

    // ── Toggle DevTools on focused view ───────────────────────────────────
    {
      accelerator: 'F12',
      label: 'DevTools (focused view)',
      action: () => {
        for (const view of Object.values(views)) {
          if (view.webContents.isFocused()) {
            view.webContents.toggleDevTools();
            return;
          }
        }
        mainWindow.webContents.toggleDevTools();
      },
    },
  ];

  for (const hk of hotkeys) {
    const registered = globalShortcut.register(hk.accelerator, hk.action);
    if (!registered) {
      console.warn(`[HOTKEY] Failed to register: ${hk.accelerator} (${hk.label})`);
    } else {
      console.log(`[HOTKEY] Registered: ${hk.accelerator} → ${hk.label}`);
    }
  }

  // Expose hotkey map to renderer for the overlay help panel
  ipcMain.handle('hotkeys:list', () => hotkeys.map(h => ({
    accelerator: h.accelerator,
    label: h.label,
  })));
}

// ─────────────────────────────────────────────────────────────────────────────
// APP LIFECYCLE
// ─────────────────────────────────────────────────────────────────────────────

app.whenReady().then(() => {
  // Suppress default menu bar
  Menu.setApplicationMenu(null);

  initDatabase();
  sessionId = startSession();

  createWindow();
  setupIPC();

  // Create the three embedded views AFTER the main window exists
  views.ddb = createView(
    'ddb',
    URLS.ddb,
    'preload-ddb.js'    // ← The magic preload that intercepts rolls
  );

  views.roll20 = createView(
    'roll20',
    URLS.roll20,
    null                // No preload needed; we control it via executeJavaScript
  );

  views.discord = createView(
    'discord',
    URLS.discord,
    null
  );

  // Initial tile pass (window may already be sized)
  tileViews();
});

app.on('window-all-closed', () => {
  // End the session in DB
  if (db && sessionId) {
    db.prepare(`UPDATE sessions SET ended_at = ? WHERE id = ?`)
      .run(new Date().toISOString(), sessionId);
    console.log('[DB] Session ended:', sessionId);
  }

  globalShortcut.unregisterAll();

  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
